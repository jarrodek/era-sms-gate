var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-18021184-1']);
_gaq.push(['_trackPageview']);
(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = 'https://ssl.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

/**
 *  Tracks a single button click.  You can use the _trackEvent command
 *  to track user interactions with different parts of your extension.
 */
function trackButton(button_id) {
_gaq.push(['_trackEvent', 'button' + button_id, 'clicked']);
}